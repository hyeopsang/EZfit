import './App.css';
import Intro from './compnent/Intro';
import Stacks from './compnent/Stacks';
import Project from './compnent/Project';
import About from './compnent/About';

function App() {
  return (
    <div className="App">
      <Intro />
      <About />
      <Stacks />
      <Project />
    </div>
  );
}

export default App;
