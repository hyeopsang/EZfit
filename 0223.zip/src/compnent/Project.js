import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import styled from "styled-components";
import arrow from "../img/arrow_1.png"
import AppleMain from "../img/AppleMain.png"
import NewMain from "../img/NewMain.png"
import "./Project.css";
import { useState, useEffect } from "react";

function Next(props) {
    const { className, style, onClick } = props;
    return (
        <img
            src={arrow}
            width={30}
            height={30}
            className="next"
            onClick={onClick}
        />
    )
}
function Prev(props) {
    const { className, style, onClick } = props;
    return (
        <img 
            src={arrow}
            className="prev"
            onClick={onClick}
        />
    )
}


const Project = () => {

    const [backColor, setBackColor] = useState(0);
    const slideColor = ['#BFC8D7', '#E2D2D2', '#E3E2B4' ]
   
    const [noneTxt, setNoneTxt] = useState(0);
    const showTxt = ['none', 'block']
   

    const settings = {
        dots: true,
        fade: true,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1, 
        nextArrow: <Next/>,
        prevArrow: <Prev/>,
        beforeChange: (current, next) => {
            setBackColor(next);
            setNoneTxt(next);
        }
      };

    return(
        <div className="Project" style={{ background: slideColor[backColor]}}>
            <h2>PROJECT</h2>
            <div className="project_in">
                <Slider {...settings}>
                    <div className="slide_item item1"style={{backgroundColor: slideColor[0]}}>
                        <div className="project_Img"><img src={AppleMain}/></div>
                        <div className="hover"><button>사이트 바로가기</button></div>
                    </div>
                    <div className="slide_item item2"style={{backgroundColor: slideColor[1]}}>
                        <div className="project_Img"><img src={NewMain}/></div>
                        <div className="project_about"></div>
                        <div className="hover"><button>사이트 바로가기</button></div>
                    </div>
                    <div className="slide_item item3" style={{backgroundColor: slideColor[2]}}>
                        <div className="project_Img"></div>
                        <div className="project_about"></div>
                        <div className="hover"><button>사이트 바로가기</button></div>
                    </div>
                </Slider>
                <div className="project_about" >
                    <div className={`about1 ${backColor === 0 ? "show" : "hide"}`}>1111</div>
                    <div className={`about2 ${backColor === 1 ? "show" : "hide"}`}>2222</div>
                    <div className={`about3 ${backColor === 2 ? "show" : "hide"}`}>3333</div>
                </div>
            </div>
        </div>
    )
}

export default Project;

