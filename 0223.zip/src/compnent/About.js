import "./About.css";

const About = () => {


    return (
        <div className="About"></div>
    )
}

export default About;