import "./Header.css";

const Header = () => {
    return (
        <div className="Header">
            <div className="menu">
                <div className="menu_intro">
                    <p>INTRO</p>
                </div>
                <div className="menu_about">
                    <p>ABOUT</p>
                </div>
                <div className="menu_stacks">
                    <p>STAKS</p>
                </div>
                <div className="menu_project">
                    <p>PROJECT</p>
                </div>
                <div className="menu_contact">
                    <p>CONTACT</p>
                </div>
            </div>
        </div>
    )
}

export default Header;